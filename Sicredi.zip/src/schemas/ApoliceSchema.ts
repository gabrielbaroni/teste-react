export interface ApoliceSchema {
  numero: string;
  valor_premio: string;
  segurado: any;
  coberturas: any;
}
