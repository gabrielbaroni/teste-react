import styled from "styled-components";

export const Background = styled.div`
  background-color: '#3ea110';
`;
