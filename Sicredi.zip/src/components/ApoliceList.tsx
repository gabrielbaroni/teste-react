import { Box, HStack, Spacer, Text, VStack } from "native-base";
import { FlatList } from "react-native";
import { Link } from "react-router-dom";

export default function ApoliceList(props: any) {
  return (
    <FlatList
      data={props.data}
      renderItem={({ item }: any) => (
        <Box key={item.id} borderBottomWidth="1" borderColor="muted.800" pl={["0", "4"]} pr={["0", "5"]} py="2">
          <HStack space={[2, 3]} justifyContent="space-between">
            <VStack>
              <Text color="coolGray.800" bold>
                {item.numero}
              </Text>
              <Text color="coolGray.600">{item.valor_premio}</Text>
            </VStack>
            <Spacer />
            <Text fontSize="xs" color="coolGray.800" alignSelf="flex-start">
              {item.segurado.nome} - {item.segurado.email} - {item.segurado.cpf_cnpj}
            </Text>
            <VStack ml={5}>
              <Link to={`/apolices/${item.id}`}>Editar</Link>
            </VStack>
          </HStack>
        </Box>
      )}
      ListEmptyComponent={<Text>Nenhuma apólice encontrada.</Text>}
      keyExtractor={(item: any, index) => item.id}
    />
  );
}
