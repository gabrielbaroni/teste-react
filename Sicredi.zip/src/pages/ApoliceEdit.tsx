import { useEffect, useState } from "react";
import { Text, View } from "react-native";
import { useParams } from "react-router-dom";
import axios from "axios";

export default function ApoliceEdit() {
  const [apolice, setApolice] = useState();
  const { id } = useParams();

  const getApolice = async () => {
    // setLoadApolices(true);
    axios
      .get(`http://localhost:1000/apolices/${id}`)
      .then((r: any) => {
        console.log(" R ", r);
        setApolice(r);
      })
      .finally(() => {
        // setLoadApolices(false);
      });
  };

  useEffect(() => {
    getApolice();
  }, []);

  return (
    <View>
      <Text>ApoliceEdit {id}</Text>
    </View>
  );
}
