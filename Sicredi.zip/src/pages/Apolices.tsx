import { useEffect, useState } from "react";
import { Button, Input, InputGroup, InputLeftAddon, Spinner, Text, VStack } from "native-base";
import { useForm } from "react-hook-form";
import axios from "axios";
import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";

import ApoliceList from "../components/ApoliceList";

export const Apolices = () => {
  const [apolices, setApolices] = useState<any>([]);
  const [loadApolices, setLoadApolices] = useState(true);

  const formOptions = {
    resolver: yupResolver(
      Yup.object().shape({
        id: Yup.string(),
        numero: Yup.string().required("Informe um número."),
        valor_premio: Yup.string().required("Informe um valor do prêmio."),
        segurado: Yup.object().shape({
          nome: Yup.string(),
          email: Yup.string(),
          cpf_cnpj: Yup.string(),
        }),
        coberturas: Yup.object().shape({
          nome: Yup.string(),
          valor: Yup.string(),
        }),
      })
    ),
  };

  const {
    getValues,
    setValue,
    handleSubmit,
    formState: { errors },
  } = useForm(formOptions);

  const onSubmit = () => {
    const formData = getValues();
    formData.id = (Math.floor(Math.random() * 999999) + 1).toString();

    axios.post(`http://localhost:1000/apolices`, formData).then((r) => {
      console.log(" R ", r);
    });
  };

  const getApolices = async () => {
    setLoadApolices(true);
    axios
      .get(`http://localhost:1000/apolices`)
      .then((r) => {
        console.log(" R ", r);
        setApolices(r);
      })
      .finally(() => {
        setLoadApolices(false);
      });
  };

  useEffect(() => {
    getApolices();
  }, []);

  return (
    <>
      <VStack flexDir={"row"} bg={"white"} p={20} mt={20} mb={50} w={"90%"} borderRadius={20}>
        <VStack flex={1} mr={10}>
          <Text textTransform={"uppercase"} fontWeight={"800"} fontSize={24}>
            Apolices
          </Text>
          {loadApolices ? <Spinner size="lg" /> : <ApoliceList data={apolices} key={1} />}
        </VStack>

        <VStack flex={1}>
          <VStack w={"40%"}>
            <Text textTransform={"uppercase"} fontWeight={"800"} fontSize={24}>
              Cadastre uma apólice
            </Text>
            <Text>Informe corretamente os dados abaixo:</Text>
            <VStack mt={7}>
              <Input variant="underlined" placeholder="Número" onChangeText={(e) => setValue("numero", e)} value={getValues() ? getValues("numero") : ""} />
              {errors && errors.numero && <Text style={{ color: "red" }}>{errors.numero.message?.toString()}</Text>}
            </VStack>
            <VStack mt={5}>
              <Input variant="underlined" placeholder="Valor do Prêmio" onChangeText={(e) => setValue("valor_premio", e)} value={getValues() ? getValues("valor_premio") : ""} />
              {errors && errors.valor_premio && <Text style={{ color: "red" }}>{errors.valor_premio.message?.toString()}</Text>}
            </VStack>
            <VStack mt={5}>
              <Input variant="underlined" placeholder="Nome do Segurado" onChangeText={(e) => setValue("segurado.nome", e)} value={getValues() ? getValues("segurado.nome") : ""} />
              {errors && errors.segurado?.nome && <Text style={{ color: "red" }}>{errors.segurado?.nome.message?.toString()}</Text>}
            </VStack>
            <VStack mt={5}>
              <Input variant="underlined" placeholder="E-mail do Segurado" onChangeText={(e) => setValue("segurado.email", e)} value={getValues() ? getValues("segurado.email") : ""} />
              {errors && errors.segurado?.email && <Text style={{ color: "red" }}>{errors.segurado?.email.message?.toString()}</Text>}
            </VStack>
            <VStack mt={5}>
              <Input variant="underlined" placeholder="CPF/CNPJ do Segurado" onChangeText={(e) => setValue("segurado.cpf_cnpj", e)} value={getValues() ? getValues("segurado.cpf_cnpj") : ""} />
              {errors && errors.segurado?.cpf_cnpj && <Text style={{ color: "red" }}>{errors.segurado?.cpf_cnpj.message?.toString()}</Text>}
            </VStack>
            <VStack mt={5}>
              <Text textTransform={"uppercase"}>coberturas</Text>
              <VStack mt={5} flexDir={"row"}>
                <Input type="text" placeholder="Nome da cobertura" mr={0} onChangeText={(e) => setValue("coberturas.nome", e)} value={getValues() ? getValues("coberturas.nome") : ""} />
                <InputGroup w={{ base: "50%", md: "285" }}>
                  <InputLeftAddon children={"R$"} />
                  <Input w={{ base: "50%", md: "211" }} placeholder="Valor do prêmio" onChangeText={(e) => setValue("coberturas.valor", e)} value={getValues() ? getValues("coberturas.valor") : ""} />
                </InputGroup>
              </VStack>
            </VStack>

            <VStack mt={5}>
              <Button onPress={handleSubmit(onSubmit)} bg={"#3ea110"} _hover={{ background: "#3ea110c4" }}>
                Cadastrar apólice
              </Button>
            </VStack>
          </VStack>
        </VStack>
      </VStack>
    </>
  );
};
